<?php
namespace Excellence\Facebook\Controller\Account;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Customer\Model\Session;
use Magento\Framework\App\RequestInterface;
use Excellence\Facebook\Model\Facebook\Config;

class Index extends Action
{
    private $resultPageFactory;

    private $session;

    private $config;

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        Session $customerSession,
        Config $config
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->session = $customerSession;
        $this->config = $config;

        parent::__construct($context);
    }

    public function execute()
    {
        return $this->resultPageFactory->create();
    }

    public function dispatch(RequestInterface $request)
    {
        if (!$this->session->isLoggedIn()) {
            return $this->_redirect('customer/account/login');
        }

        if (!$this->config->isEnabled()) {
            return $this->_redirect($this->_redirect->getRefererUrl());
        }

        return parent::dispatch($request);
    }
}