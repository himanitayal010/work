<?php

namespace Excellence\Facebook\Block;

use Magento\Framework\View\Element\Messages as MagentoMessage;

class Messages extends MagentoMessage
{
    protected function _prepareLayout()
    {
        $this->addMessages($this->messageManager->getMessages(true));
        return parent::_prepareLayout();
    }

}