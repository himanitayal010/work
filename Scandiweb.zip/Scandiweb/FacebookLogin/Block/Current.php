<?php

namespace Excellence\Facebook\Block;

use Magento\Framework\App\DefaultPathInterface;
use Magento\Framework\View\Element\Html\Link\Current as MagentoCurrent;
use Magento\Framework\View\Element\Template\Context;
use Excellence\Facebook\Model\Facebook\Config;

class Current extends MagentoCurrent
{
    private $config;

    public function __construct(
        Context $context,
        DefaultPathInterface $defaultPath,
        array $data,
        Config $config
    ) {
        $this->config = $config;

        parent::__construct($context, $defaultPath, $data);
    }

    protected function _toHtml()
    {
        if ($this->config->isEnabled()) {
            return parent::_toHtml();
        }

        return null;
    }

}