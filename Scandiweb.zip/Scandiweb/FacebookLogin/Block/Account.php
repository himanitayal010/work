<?php
/**
 * Scandiweb_FacebookLogin
 *
 * @category    Scandiweb
 * @package     Scandiweb_FacebookLogin
 * @author      Viktors Vipolzovs <info@scandiweb.com>
 * @copyright   Copyright (c) 2016 Scandiweb, Ltd (http://scandiweb.com)
 */

namespace Scandiweb\FacebookLogin\Block;

use Facebook\Exceptions\FacebookSDKException;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Customer\Model\Session;
use Excellence\Facebook\Model\Facebook\Facebook;
use Excellence\Facebook\Logger\Logger;
use Magento\Framework\Message\ManagerInterface;
use Exception;

class Account extends Template
{
    const FIELDS = 'id,email,first_name,last_name,middle_name,gender,picture';

    protected $facebook;

    private $customerSession;

    private $messageManager;

    private $logger;

    public function __construct(
        Context $context,
        array $data,
        Facebook $facebook,
        Session $customerSession,
        ManagerInterface $messageManager,
        Logger $logger
    ) {
        $this->facebook = $facebook;
        $this->customerSession = $customerSession;
        $this->messageManager = $messageManager;
        $this->logger = $logger;

        parent::__construct($context, $data);
    }

    public function getFacebookUser()
    {
        $facebookUser = null;
        $customer = $this->customerSession->getCustomerData();
        $accessTokenAttribute = $customer->getCustomAttribute('sf_access_token');

        if ($accessTokenAttribute) {
            /** @var $accessToken \Facebook\Authentication\AccessToken */
            $accessToken = unserialize($accessTokenAttribute->getValue());

            try {
                $facebookUser = $this->facebook->get(
                    '/me?fields=' . static::FIELDS, $accessToken
                )->getGraphUser()->all();
            } catch (FacebookSDKException $e) {
                $this->logger->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->logger->addError($e->getMessage());
            }
        }

        return $facebookUser;
    }

    public function getLoginUrl()
    {
        $facebookHelper = $this->facebook->getRedirectLoginHelper();

        return $facebookHelper->getLoginUrl($this->getUrl('facebook/login'), ['scope' => 'email']);
    }

}