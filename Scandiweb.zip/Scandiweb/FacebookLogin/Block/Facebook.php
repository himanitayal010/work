<?php

namespace Excellence\Facebook\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Excellence\Facebook\Model\Facebook\Config;
use Magento\Customer\Model\Session;
use Excellence\Facebook\Model\Facebook\Facebook as FacebookModel;

class Facebook extends Template
{
    protected $config;

    protected $facebook;

    private $customerSession;

    public function __construct(
        Context $context,
        array $data,
        Config $config,
        FacebookModel $facebook,
        Session $customerSession
    ) {
        $this->config = $config;
        $this->facebook = $facebook;
        $this->customerSession = $customerSession;

        parent::__construct($context, $data);
    }

    public function isEnabled()
    {
        return $this->config->isEnabled();
    }

    public function getLoginUrl()
    {
        $facebookHelper = $this->facebook->getRedirectLoginHelper();

        return $facebookHelper->getLoginUrl($this->getUrl('faceebook\login'), ['scope' => 'email']);
    }

    public function isLoggedIn()
    {
        return $this->customerSession->isLoggedIn();
    }

}